//
//  iOSTaskAppApp.swift
//  iOSTaskApp
//
//  Created by Saravanan R on 25/10/23.
//

import SwiftUI

@main
struct iOSTaskAppApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
